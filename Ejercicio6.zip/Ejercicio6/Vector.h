#pragma once
#define MAX 100
class Vector
{
private:
	int vec[MAX],n;

public:
	Vector(void);
	~Vector(void);
	void cargarVector(int vec[], int n); //metodos
	void mostrarVector(int vec[], int n);
	void sumarVector(int vec[], int n);
};

