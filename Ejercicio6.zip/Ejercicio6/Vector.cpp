#include "StdAfx.h"
#include "Vector.h"
#include <iostream>

using namespace std;

Vector::Vector(void)
{
	vec[10]=0;
	n=0;
}


Vector::~Vector(void)
{
}
void Vector::cargarVector(int vec[], int n){
	for(int i=0;i<n;i++){
		cout<<"vec["<<i<<"] =" ;
		cin>>vec[i];
	}
}

void Vector::mostrarVector(int vec[], int n){
	for(int i=0;i<n;i++){
		cout<<vec[i]<<", ";
	}
	cout<<endl;
}
void Vector::sumarVector(int vec[], int n)
{
	int suma=0,p1=0,p2=0,p3=0;

	p1=(vec[0]+vec[1]+vec[2])/3;
	p2=(vec[1]+vec[2]+vec[3])/3;
	p3=(vec[2]+vec[3]+vec[4])/3;
	
	cout << "promedio 1=  " << p1 << endl;
	cout << "promedio 2=  " << p2 << endl;
	cout << "promedio 3=  " << p3 << endl;
	
	suma=p1+p2+p3;

	cout<<"Suma Promedio:  "<<suma<<endl;


}