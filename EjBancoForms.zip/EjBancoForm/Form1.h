#pragma once
#include "Cuenta.h"
#include <iostream>
#include <string>
#include <msclr/marshal_cppstd.h>

namespace My305 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr::interop;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblCuenta;
	protected: 
	private: System::Windows::Forms::Label^  lblNombre;
	private: System::Windows::Forms::TextBox^  txtCuenta;
	private: System::Windows::Forms::TextBox^  txtNombre;
	private: System::Windows::Forms::TextBox^  txtMonto;
	private: System::Windows::Forms::TextBox^  txtSaldo;
	private: System::Windows::Forms::Label^  lblMonto;
	private: System::Windows::Forms::Label^  lblSaldo;
	private: System::Windows::Forms::Button^  btnIngreso;





	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblCuenta = (gcnew System::Windows::Forms::Label());
			this->lblNombre = (gcnew System::Windows::Forms::Label());
			this->txtCuenta = (gcnew System::Windows::Forms::TextBox());
			this->txtNombre = (gcnew System::Windows::Forms::TextBox());
			this->txtMonto = (gcnew System::Windows::Forms::TextBox());
			this->txtSaldo = (gcnew System::Windows::Forms::TextBox());
			this->lblMonto = (gcnew System::Windows::Forms::Label());
			this->lblSaldo = (gcnew System::Windows::Forms::Label());
			this->btnIngreso = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblCuenta
			// 
			this->lblCuenta->AutoSize = true;
			this->lblCuenta->Location = System::Drawing::Point(46, 41);
			this->lblCuenta->Name = L"lblCuenta";
			this->lblCuenta->Size = System::Drawing::Size(41, 13);
			this->lblCuenta->TabIndex = 0;
			this->lblCuenta->Text = L"Cuenta";
			// 
			// lblNombre
			// 
			this->lblNombre->AutoSize = true;
			this->lblNombre->Location = System::Drawing::Point(46, 94);
			this->lblNombre->Name = L"lblNombre";
			this->lblNombre->Size = System::Drawing::Size(44, 13);
			this->lblNombre->TabIndex = 1;
			this->lblNombre->Text = L"Nombre";
			// 
			// txtCuenta
			// 
			this->txtCuenta->Location = System::Drawing::Point(153, 34);
			this->txtCuenta->Name = L"txtCuenta";
			this->txtCuenta->Size = System::Drawing::Size(100, 20);
			this->txtCuenta->TabIndex = 2;
			// 
			// txtNombre
			// 
			this->txtNombre->Location = System::Drawing::Point(153, 87);
			this->txtNombre->Name = L"txtNombre";
			this->txtNombre->Size = System::Drawing::Size(100, 20);
			this->txtNombre->TabIndex = 3;
			// 
			// txtMonto
			// 
			this->txtMonto->Location = System::Drawing::Point(153, 141);
			this->txtMonto->Name = L"txtMonto";
			this->txtMonto->Size = System::Drawing::Size(100, 20);
			this->txtMonto->TabIndex = 4;
			// 
			// txtSaldo
			// 
			this->txtSaldo->Location = System::Drawing::Point(153, 196);
			this->txtSaldo->Name = L"txtSaldo";
			this->txtSaldo->Size = System::Drawing::Size(100, 20);
			this->txtSaldo->TabIndex = 5;
			this->txtSaldo->TextChanged += gcnew System::EventHandler(this, &Form1::txtIngreso_TextChanged);
			// 
			// lblMonto
			// 
			this->lblMonto->AutoSize = true;
			this->lblMonto->Location = System::Drawing::Point(46, 148);
			this->lblMonto->Name = L"lblMonto";
			this->lblMonto->Size = System::Drawing::Size(37, 13);
			this->lblMonto->TabIndex = 6;
			this->lblMonto->Text = L"Monto";
			// 
			// lblSaldo
			// 
			this->lblSaldo->AutoSize = true;
			this->lblSaldo->Location = System::Drawing::Point(46, 203);
			this->lblSaldo->Name = L"lblSaldo";
			this->lblSaldo->Size = System::Drawing::Size(34, 13);
			this->lblSaldo->TabIndex = 7;
			this->lblSaldo->Text = L"Saldo";
			// 
			// btnIngreso
			// 
			this->btnIngreso->Location = System::Drawing::Point(120, 226);
			this->btnIngreso->Name = L"btnIngreso";
			this->btnIngreso->Size = System::Drawing::Size(75, 23);
			this->btnIngreso->TabIndex = 8;
			this->btnIngreso->Text = L"Ingreso";
			this->btnIngreso->UseVisualStyleBackColor = true;
			this->btnIngreso->Click += gcnew System::EventHandler(this, &Form1::btnIngreso_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->btnIngreso);
			this->Controls->Add(this->lblSaldo);
			this->Controls->Add(this->lblMonto);
			this->Controls->Add(this->txtSaldo);
			this->Controls->Add(this->txtMonto);
			this->Controls->Add(this->txtNombre);
			this->Controls->Add(this->txtCuenta);
			this->Controls->Add(this->lblNombre);
			this->Controls->Add(this->lblCuenta);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void txtIngreso_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void btnIngreso_Click(System::Object^  sender, System::EventArgs^  e) {
			 Cuenta cuentita;
			 cuentita.set_Nombre(marshal_as<std::string>(System::Convert::ToString(txtNombre->Text)));
			 cuentita.set_Cuenta(marshal_as<std::string>(System::Convert::ToString(txtCuenta->Text)));
			 cuentita.ingreso(System::Convert::ToDouble(txtMonto->Text));
			 txtSaldo->Text=System::Convert::ToString(cuentita.Estado());
		 }
};
}