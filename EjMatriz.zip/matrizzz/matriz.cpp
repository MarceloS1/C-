#include "StdAfx.h"
#include "matriz.h"
#include "conio.h"
#include <iostream>

using namespace std;
matriz::matriz(void)
{
	int v1[MAX][MAX] ;
}
matriz::~matriz(void)
{
}
void matriz::ingresar(int v1[MAX][MAX])
{
	for (int i = 0; i < MAX; i++)
	{
		for (int j = 0; j < MAX; j++)
		{
			cout << "[" << i << "][" << j << "] = ";
			cin >> v1[i][j];
		}

	}
}
void matriz::mostrar(int v1[MAX][MAX])
{
	for (int i = 0; i < MAX; i++)
	{
		for (int j = 0; j < MAX; j++)
		{
			cout << v1[i][j] << "  ";
		}

	}
	cout << endl;
}
void matriz::sumardiag(int v1[MAX][MAX])
{
	int aux = 0;
	for (int i = 0; i < MAX; i++)
	{
		for (int j = 0; j < MAX; j++)
		{
			if (i == j)
			{
				aux = aux + v1[i][j];
			}
		}

	}
	cout << "La suma de las diagonales es : " << aux << endl;

}
void matriz::sumacolumn(int v1[MAX][MAX])
{
	int column;
	int aux = 0;
	do {
		cout << "Ingrese la columna que desea sumar : " << endl;
		cin >> column;
		if (column >= 2)
		{
			cout << "Error, debe ser menor a 2" << endl;
		}
	} while (column >= 2);

		for (int i = 0; i < MAX; i++)
		{
			for (int j = 0; j < MAX; j++)
			{
				if (j == column)
				{
					aux = aux + v1[i][j];
				}
			}
		}
	cout << "La suma de la : " << column << " es : " << aux << endl;

}