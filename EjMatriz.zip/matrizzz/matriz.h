#pragma once
#define MAX 2
class matriz
{
private:
    int v1[MAX][MAX];


public:
    matriz(void);
    ~matriz(void);
    void ingresar(int v1[MAX][MAX]);
    void mostrar(int v1[MAX][MAX]);
    void sumardiag(int v1[MAX][MAX]);
    void sumacolumn(int v1[MAX][MAX]);
};

