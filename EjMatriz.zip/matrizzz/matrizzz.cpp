// matrizzz.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include "matriz.h"
#include <iostream>

using namespace std;


int main()
{
	int v1[MAX][MAX];
	int op;
	matriz matriz1;
	cout << "Ingresar Matriz : " << endl;
	matriz1.ingresar(v1);
	do {
		cout << "MENU" << endl;
		cout << "1.-Mostrar Matriz : " << endl;
		cout << "2.-Suma diagonal de la Matriz : " << endl;
		cout << "3.-Suma de columna deseada Matriz : " << endl;
		cout << "0.-Salir" << endl;
		cin >> op;
		switch (op) {
		case 1:
			matriz1.mostrar(v1);
			break;
		case 2:
			matriz1.sumardiag(v1);
			break;
		case 3:
			matriz1.sumacolumn(v1);
			break;
		default:
			cout << "ERROR OPCION NO VALIDA" << endl;
		}
	} while (op != 0);


	getch();
}

