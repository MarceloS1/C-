#include "StdAfx.h"
#include "Pila.h"
#include <iostream>

using namespace std;
Pila::Pila(void)
{
	iniciar();
}
Pila::~Pila(void)
{
}
void Pila::iniciar()
{
	tope=-1;
}
int Pila::gettope()
{
	return tope;
}

bool Pila::Desapilar()
{
	bool res;
	if(PilaVacia()==true)
	{res=false;}
	else {tope--;
	res=true;}
	return res;
}
bool Pila::Apilar(int elemento)
{
	if(pilallena(tope))
	{
		return false;
	}
	else
	{tope++;
	pila[tope]==elemento;}
	return true;
}
void Pila::verpila()
{
	for(int i=0; i<=tope;i++)
	{
		cout<<"Pila["<<pila[i]<<"]"<<endl;
	}
}
bool Pila::PilaVacia()
{
	if(gettope()==-1)
		return true;
	else
		return false;
}
bool Pila::pilallena(int tope)
{
	if(gettope()==MAX-1)
		return true;
	else
		return false;
}

