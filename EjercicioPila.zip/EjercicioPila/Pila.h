#pragma once
#define MAX 100
class Pila
{
private:
	int pila[MAX];
	int tope;
public:
	Pila(void);
	~Pila(void);
	void iniciar();
	int gettope();
	bool Apilar(int elemento);
    void verpila();
	bool PilaVacia();
	bool Desapilar();
	bool pilallena(int tope);
};


