// EjercicioPila.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Pila.h"
#include <iostream>
#include "conio.h"

#define MAX 100
using namespace std;
int main()
{
	int n;
	Pila pila1;
		for(int i=0; i<10; i++)
		{
			cout<<"pila["<<i<<"]"<<endl;
			cin>>n;
			pila1.Apilar(n);
		}
		for(int i=0;i<10;i++)
		{
			cout<<n<<endl;
			pila1.Desapilar();
		}
	getch();

}

