#pragma once
#define MAX 100
class Cola
{
private:
	int info[MAX];
	int ini;
	int fin;
public:
	Cola(void);
	~Cola(void);
	bool ColaVacia();
	bool Encolar(int Valor);
	bool Desencolar();
	void mostrar();
};

