#include "StdAfx.h"
#include "Cola.h"
#include <iostream>

using namespace std;

Cola::Cola(void)
{
	ini=0;
	fin=0;
}

Cola::~Cola(void)
{
}

bool Cola::ColaVacia()
{
	bool b_aux;
	if(ini==fin)
	{b_aux=true;}
	else
	{b_aux=false;}
	return b_aux;
}
bool Cola::Encolar(int Valor)
{
	bool error;
	if(fin==MAX)
	{error=true;}
	else
	{error=false;
	info[fin]=Valor;
	fin++;}
	return error;
}

bool Cola::Desencolar()
{
	bool error;
	if(ColaVacia())
	{error=true;}
	else
	{error=false;
	ini++;}
	return error;
}
void Cola::mostrar()
{
	for(int i=ini;i<fin;i++)
		cout<<"["<<info[i]<<"]\n";
		cout<<"--------------\n";
}