

#include "stdafx.h"
#include "Cola.h"
#include <iostream>
#include "conio.h"

using namespace std;

void main()
{
	Cola cola2020;
	int valor;

	for(int i=2;i<=20;i++)
		if(i%2==1 || !cola2020.Encolar(i))
			cola2020.mostrar();
		else 
			cout<<"Error";
	getch();
}
//mustra como se va encolando poco a poco

