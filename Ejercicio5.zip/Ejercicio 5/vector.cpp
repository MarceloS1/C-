#include "StdAfx.h"
#include "vector.h"
#include "iostream"

	void vector::cargartam(int t)
	{
		tama�o=t;
	}
	void vector::cargar()
	{
		for(int i=0; i< tama�o; i++)
		{
		 cout<< "v["<<i<<"]=";
		 cin>>v[i];
		}
	}
	void vector::invertir()
	{
		for(int i=0; i<tama�o; i++)
		{
			r[tama�o-1-i]=v[i];
		}
	}
	void vector::mostrar()
	{
	for(int i=0;i<tama�o; i++)
	{
	cout<<"r["<<i<<"]="<<r[i]<<"\n";
	}
	}
	void vector::capicua()
	{
		for(int i=0; i<tama�o; i++)
		{
			if(v[i]==r[i])
			{
				cout<<"es capicua \n";
			}
			else
			{
				cout<<"no es capicua \n";
			}
		}
	}
