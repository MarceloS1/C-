
#include "stdafx.h"
#include "vector.h"
#include "iostream"
using namespace std;

int main()
{
	int tam;
vector  vectorcito;

do
{
cout<<"cuantos datos hay en el vector /n";
cin>>tam;
}
while((tam<0)||(tam>100));
vectorcito.cargartam(tam);
vectorcito.cargar(); 
cout<<endl;
vectorcito.invertir();
vectorcito.mostrar();
vectorcito.capicua();
system("pause");
}



