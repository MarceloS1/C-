#pragma once
#include "stdafx.h"
#include "iostream"
using namespace std;
#define MAX 100
class vector
{
private:
	float v[MAX];
	float r[MAX];
	int tama�o;
public:
	void cargartam(int t);
	void cargar();
	void invertir();
	void mostrar();
	void capicua();
}

